package com.amrita.jpl.cys21055.p2;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
abstract class Quizgame{
    abstract void startGame();
    abstract void askQuestion();
    abstract void evaluateAnswer(String answer);
}

interface QuizGameListener{
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}

class QuizGameServer extends Quizgame{
    private List<String> ques;
    private List<QuizGameListener> listen;

    public QuizGameServer(){
        ques = new ArrayList<>();
        Questions();
    }

    private void Questions() {
        ques.add("what is the sum of 2 and 3 ?");
        ques.add("what is the product of 5 and 6 ?");
    }

    public void addClient(QuizGameListener listener) {
        listen.add(listener);
    }
    public void removeClient(QuizGameListener listener) {
        listen.remove(listener);
    }
    void startGame() {
        askQuestion();
    }
    void askQuestion(){
        Random r = new Random();
        int i = r.nextInt();
        String question = ques.get(i);
        notifyQuestionAsked(question);
    }

    private void notifyQuestionAsked(String question) {
        for (QuizGameListener listener : listen) {
            listener.onQuestionAsked(question);
        }
    }

    void evaluateAnswer(String ans){
        boolean c;
        if(ans.equals("5") || ans.equals("30")) {
            c = true;
        }
        else {
            c = false;
        }
        notifyAnswerEvaluated(c);
    }

    private void notifyAnswerEvaluated(boolean c) {
        for (QuizGameListener listener : listen) {
            listener.onAnswerEvaluated(c);
        }
    }

}

class QuizGameClient extends Quizgame implements QuizGameListener {
    private QuizGameServer server;

    public QuizGameClient(QuizGameServer server) {
        this.server = server;
    }

    void startGame() {
        server.addClient(this);
        server.startGame();
    }

    public void onQuestionAsked(String question) {
        askQuestion();
        System.out.println(question);
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {

    }

    public void onAnswerEvaluated(Boolean a) {
        System.out.println("The answer is " + (a ? "correct!" : "incorrect!"));
    }

    void askQuestion(){};
    /**
     * @param answer this will send the answer for checking whether the answer is correct or not
     */
    void evaluateAnswer(String answer) {
        server.evaluateAnswer(answer);
    }
}

/**
 * @author Penugonda V S Ganasekhar
 * @version 0.5
 */
public class periodical2 {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        QuizGameServer server = new QuizGameServer();
        QuizGameClient client = new QuizGameClient(server);
        client.startGame();
        String ans = s.next();
        client.evaluateAnswer(ans);
    }
}
